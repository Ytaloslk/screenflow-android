# ScreenFlow — Android → Android TV / Google TV

Projeto Android com dois aplicativos: `sender` (celular) e `tv` (televisão). O objetivo é espelhar a tela pela mesma rede Wi‑Fi usando captura MediaProjection e transporte WebRTC local.

## Gerar os APKs sem computador

O projeto inclui o workflow `.github/workflows/android.yml` para compilar os dois APKs no GitHub Actions.

1. Envie **todo o conteúdo desta pasta `ScreenFlow`** para a raiz do repositório `Ytaloslk/screenflow-android`, mantendo as pastas e arquivos.
2. No GitHub, abra a aba **Actions** e habilite workflows, se solicitado.
3. Selecione **Build ScreenFlow APKs** e toque em **Run workflow**. Também haverá compilação automática após um push na branch `main`.
4. Quando a execução terminar com sucesso, abra a execução e baixe o artefato **screenflow-apks**.
5. O ZIP do artefato contém `tv-debug.apk` e `sender-debug.apk`.
6. Instale primeiro `tv-debug.apk` na Android TV / Google TV e depois `sender-debug.apk` no celular. Ambos devem estar na mesma rede Wi‑Fi.

## Importante

Esta é uma base inicial de desenvolvimento (0.1.0), não uma versão pronta para distribuição. Os APKs ainda precisam ser compilados e testados em dispositivos reais. O fluxo inicial usa descoberta local, captura MediaProjection, sinalização TCP local e mídia WebRTC. Áudio interno, PIN de pareamento, reconexão e ajustes avançados de qualidade ainda precisam ser desenvolvidos e validados.

Não existe latência absolutamente zero: o atraso depende do celular, da TV, do roteador, da rede e dos codecs. Para reduzir o atraso, prefira Wi‑Fi 5 GHz e evite redes de convidados ou isolamento entre clientes.

## Requisitos

- Celular Android 8.0 (API 26) ou superior.
- Android TV / Google TV 8.0 (API 26) ou superior.
- Mesma rede Wi‑Fi, com comunicação entre dispositivos permitida.
- Para compilação local: JDK 17, Android SDK Platform 35 e Gradle 8.11.1.

## Segurança

A mídia WebRTC é protegida por DTLS-SRTP. A sinalização local desta versão inicial ainda não exige PIN; use somente em uma rede Wi‑Fi confiável.
