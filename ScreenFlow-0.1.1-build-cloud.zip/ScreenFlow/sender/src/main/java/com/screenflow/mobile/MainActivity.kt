package com.screenflow.mobile

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.net.InetAddress

private data class FoundTv(val name: String, val host: InetAddress, val port: Int) {
    override fun toString(): String = "$name  •  ${host.hostAddress}:$port"
}

class MainActivity : ComponentActivity() {
    private lateinit var nsd: NsdManager
    private lateinit var list: ListView
    private lateinit var status: TextView
    private lateinit var adapter: ArrayAdapter<FoundTv>
    private val devices = mutableListOf<FoundTv>()
    private var selected: FoundTv? = null
    private var discovering = false

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val tv = selected
        if (result.resultCode == RESULT_OK && result.data != null && tv != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_HOST, tv.host.hostAddress)
                putExtra(ScreenCaptureService.EXTRA_PORT, tv.port)
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_PROJECTION_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
            status.text = "Conectando a ${tv.name}… aceite o compartilhamento de tela."
        } else {
            status.text = "Transmissão cancelada."
        }
    }

    private val discoveryListener = object : NsdManager.DiscoveryListener {
        override fun onDiscoveryStarted(serviceType: String) {
            runOnUiThread { status.text = "Procurando ScreenFlow TV na rede…" }
        }
        override fun onServiceFound(serviceInfo: NsdServiceInfo) {
            if (!serviceInfo.serviceType.contains("_screenflow._tcp")) return
            @Suppress("DEPRECATION")
            nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                    runOnUiThread { status.text = "Não foi possível identificar uma TV. Tente novamente." }
                }
                override fun onServiceResolved(info: NsdServiceInfo) {
                    val host = info.host ?: return
                    val found = FoundTv(info.serviceName, host, info.port)
                    runOnUiThread {
                        if (devices.none { it.host == found.host && it.port == found.port }) {
                            devices.add(found)
                            adapter.notifyDataSetChanged()
                            status.text = "${devices.size} dispositivo(s) encontrado(s). Selecione sua TV."
                        }
                    }
                }
            })
        }
        override fun onServiceLost(serviceInfo: NsdServiceInfo) {
            runOnUiThread {
                devices.removeAll { it.name == serviceInfo.serviceName }
                adapter.notifyDataSetChanged()
            }
        }
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
            discovering = false
            runOnUiThread { status.text = "Falha ao procurar TVs (código $errorCode)." }
            runCatching { nsd.stopServiceDiscovery(this) }
        }
        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
            runCatching { nsd.stopServiceDiscovery(this) }
        }
        override fun onDiscoveryStopped(serviceType: String) { discovering = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nsd = getSystemService(NSD_SERVICE) as NsdManager
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "SCREENFLOW"
            textSize = 28f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "Espelhamento local para Android TV / Google TV"
            textSize = 15f
            setPadding(0, 8, 0, 20)
        }
        status = TextView(this).apply {
            text = "Conecte o celular e a TV à mesma rede Wi-Fi. Abra o ScreenFlow TV na televisão."
            textSize = 14f
            setPadding(0, 8, 0, 12)
        }
        val search = Button(this).apply {
            text = "PROCURAR TV"
            setOnClickListener { startDiscovery() }
        }
        list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_activated_1, devices)
        list.adapter = adapter
        list.choiceMode = ListView.CHOICE_MODE_SINGLE
        list.setOnItemClickListener { _, _, position, _ ->
            selected = devices[position]
            list.setItemChecked(position, true)
            status.text = "TV selecionada: ${selected?.name}"
        }
        val start = Button(this).apply {
            text = "INICIAR ESPELHAMENTO"
            setOnClickListener {
                if (selected == null) {
                    status.text = "Primeiro procure e selecione sua TV."
                } else {
                    val manager = getSystemService(MediaProjectionManager::class.java)
                    projectionLauncher.launch(manager.createScreenCaptureIntent())
                }
            }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(search)
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(start)
        setContentView(root)
    }

    private fun startDiscovery() {
        if (discovering) runCatching { nsd.stopServiceDiscovery(discoveryListener) }
        devices.clear()
        selected = null
        adapter.notifyDataSetChanged()
        discovering = true
        runCatching { nsd.discoverServices("_screenflow._tcp.", NsdManager.PROTOCOL_DNS_SD, discoveryListener) }
            .onFailure { status.text = "Não foi possível iniciar a busca: ${it.message}"; discovering = false }
    }

    override fun onDestroy() {
        if (discovering) runCatching { nsd.stopServiceDiscovery(discoveryListener) }
        super.onDestroy()
    }
}
