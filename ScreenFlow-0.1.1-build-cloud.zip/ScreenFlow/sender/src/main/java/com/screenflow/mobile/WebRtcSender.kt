package com.screenflow.mobile

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import org.json.JSONObject
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.roundToInt

internal class WebRtcSender(
    private val context: Context,
    private val host: String,
    private val port: Int,
    private val resultCode: Int,
    private val projectionData: Intent,
    private val onStatus: (String) -> Unit
) {
    private val egl = EglBase.create()
    private var socket: Socket? = null
    private var channel: SignalChannel? = null
    private var factory: PeerConnectionFactory? = null
    private var peer: PeerConnection? = null
    private var capturer: ScreenCapturerAndroid? = null
    private var textureHelper: SurfaceTextureHelper? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    @Volatile private var remoteDescriptionSet = false
    private val pendingCandidates = mutableListOf<IceCandidate>()

    fun start() {
        onStatus("Conectando à TV $host:$port")
        val s = Socket()
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(host, port), 7000)
        socket = s
        channel = SignalChannel(s)
        initializeWebRtc()
        Thread({ runCatching { channel?.readLoop(::handleSignal) }.onFailure { Log.e(TAG, "Sinalização encerrada", it) } }, "ScreenFlowSignalRead").start()
        createOffer()
    }

    private fun initializeWebRtc() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions()
        )
        val encoder = DefaultVideoEncoderFactory(egl.eglBaseContext, true, true)
        val decoder = DefaultVideoDecoderFactory(egl.eglBaseContext)
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoder)
            .setVideoDecoderFactory(decoder)
            .createPeerConnectionFactory()

        val config = PeerConnection.RTCConfiguration(emptyList())
        config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        peer = factory?.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                onStatus("Conexão WebRTC: ${state?.name ?: "desconhecida"}")
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate ?: return
                sendCandidate(candidate)
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: org.webrtc.MediaStream?) {}
            override fun onRemoveStream(stream: org.webrtc.MediaStream?) {}
            override fun onDataChannel(dataChannel: org.webrtc.DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: org.webrtc.RtpReceiver?, mediaStreams: Array<out org.webrtc.MediaStream>?) {}
            override fun onTrack(transceiver: org.webrtc.RtpTransceiver?) {}
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {
                onStatus("Estado da conexão: ${newState?.name ?: "desconhecido"}")
            }
        }) ?: error("Não foi possível criar a conexão WebRTC")

        videoSource = factory!!.createVideoSource(true)
        textureHelper = SurfaceTextureHelper.create("ScreenFlowCapture", egl.eglBaseContext)
        capturer = ScreenCapturerAndroid(projectionData, object : MediaProjection.Callback() {
            override fun onStop() {
                onStatus("Captura de tela encerrada pelo Android")
                stop()
            }
        })
        capturer!!.initialize(textureHelper!!, context, videoSource!!.capturerObserver)
        val size = captureSize()
        capturer!!.startCapture(size.first, size.second, 30)
        val track = factory!!.createVideoTrack("screenflow-screen", videoSource)
        videoTrack = track
        peer!!.addTrack(track, listOf("screenflow-stream"))
        onStatus("Tela capturada; negociando vídeo…")
    }

    private fun captureSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels.coerceAtLeast(1)
        val h = metrics.heightPixels.coerceAtLeast(1)
        val scale = minOf(1.0, 1920.0 / maxOf(w, h).toDouble())
        return (w * scale).roundToInt().coerceAtLeast(1) to (h * scale).roundToInt().coerceAtLeast(1)
    }

    private fun createOffer() {
        peer?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(description: SessionDescription?) {
                description ?: return
                peer?.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        channel?.send(JSONObject().put("type", "offer").put("sdp", description.description))
                        onStatus("Oferta enviada à TV; aguardando resposta…")
                    }
                    override fun onSetFailure(error: String?) { onStatus("Falha ao preparar oferta: $error") }
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onCreateFailure(p0: String?) {}
                }, description)
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(error: String?) { onStatus("Falha ao criar oferta: $error") }
            override fun onSetFailure(error: String?) {}
        }, MediaConstraints())
    }

    private fun handleSignal(message: JSONObject) {
        when (message.optString("type")) {
            "answer" -> {
                val sdp = message.optString("sdp")
                peer?.setRemoteDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        synchronized(pendingCandidates) {
                            pendingCandidates.forEach { peer?.addIceCandidate(it) }
                            pendingCandidates.clear()
                        }
                        onStatus("Resposta recebida; conectando vídeo…")
                    }
                    override fun onSetFailure(error: String?) { onStatus("Resposta inválida: $error") }
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onCreateFailure(p0: String?) {}
                }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
            }
            "candidate" -> {
                val candidate = IceCandidate(
                    message.optString("sdpMid"),
                    message.optInt("sdpMLineIndex"),
                    message.optString("candidate")
                )
                if (remoteDescriptionSet) peer?.addIceCandidate(candidate)
                else synchronized(pendingCandidates) { pendingCandidates.add(candidate) }
            }
            "error" -> onStatus("TV: ${message.optString("message")}")
        }
    }

    private fun sendCandidate(candidate: IceCandidate) {
        runCatching {
            channel?.send(JSONObject()
                .put("type", "candidate")
                .put("sdpMid", candidate.sdpMid)
                .put("sdpMLineIndex", candidate.sdpMLineIndex)
                .put("candidate", candidate.sdp))
        }.onFailure { Log.w(TAG, "Não foi possível enviar candidato ICE", it) }
    }

    fun stop() {
        runCatching { capturer?.stopCapture() }
        runCatching { capturer?.dispose() }
        capturer = null
        videoTrack?.dispose(); videoTrack = null
        videoSource?.dispose(); videoSource = null
        textureHelper?.dispose(); textureHelper = null
        peer?.close(); peer?.dispose(); peer = null
        factory?.dispose(); factory = null
        channel?.close(); channel = null
        runCatching { socket?.close() }; socket = null
        egl.release()
    }

    companion object { private const val TAG = "ScreenFlowWebRTC" }
}
