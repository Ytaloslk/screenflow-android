package com.screenflow.mobile

import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.Socket

internal class SignalChannel(private val socket: Socket) {
    private val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
    private val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))

    @Synchronized
    fun send(message: JSONObject) {
        writer.write(message.toString())
        writer.newLine()
        writer.flush()
    }

    fun readLoop(onMessage: (JSONObject) -> Unit) {
        while (!socket.isClosed) {
            val line = reader.readLine() ?: break
            runCatching { JSONObject(line) }.onSuccess(onMessage)
        }
    }

    fun close() { runCatching { socket.close() } }
}
