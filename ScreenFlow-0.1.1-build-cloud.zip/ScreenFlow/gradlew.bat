@echo off
setlocal
set "GRADLE_HOME=%USERPROFILE%\.gradle\screenflow\gradle-8.11.1"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $base=Join-Path $env:USERPROFILE '.gradle\screenflow'; New-Item -ItemType Directory -Force -Path $base | Out-Null; $zip=Join-Path $base 'gradle-8.11.1-bin.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath $base -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
