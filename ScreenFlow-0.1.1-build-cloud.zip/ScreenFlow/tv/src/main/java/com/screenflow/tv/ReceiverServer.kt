package com.screenflow.tv

import android.util.Log
import java.net.ServerSocket
import java.net.Socket

internal class ReceiverServer(
    private val port: Int,
    private val onClient: (Socket) -> Unit,
    private val onStatus: (String) -> Unit
) {
    @Volatile private var running = false
    private var serverSocket: ServerSocket? = null

    fun start() {
        if (running) return
        running = true
        Thread({
            try {
                val server = ServerSocket(port)
                serverSocket = server
                onStatus("ScreenFlow TV ativo na porta $port")
                while (running) {
                    val client = server.accept()
                    client.tcpNoDelay = true
                    onStatus("Celular conectado; preparando transmissão…")
                    onClient(client)
                }
            } catch (error: Exception) {
                if (running) {
                    Log.e(TAG, "Erro no servidor local", error)
                    onStatus("Erro no receptor: ${error.message}")
                }
            }
        }, "ScreenFlowReceiverServer").start()
    }

    fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
    }

    companion object { private const val TAG = "ScreenFlowServer" }
}
