package com.screenflow.tv

import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import org.webrtc.EglBase
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import java.net.Socket

class MainActivity : ComponentActivity() {
    private lateinit var renderer: SurfaceViewRenderer
    private lateinit var status: TextView
    private lateinit var egl: EglBase
    private lateinit var server: ReceiverServer
    private lateinit var nsd: NsdManager
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var receiver: WebRtcReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        buildUi()
        egl = EglBase.create()
        renderer.init(egl.eglBaseContext, null)
        renderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
        renderer.setEnableHardwareScaler(true)
        renderer.setMirror(false)

        nsd = getSystemService(NSD_SERVICE) as NsdManager
        server = ReceiverServer(PORT, ::onClientConnected) { message -> runOnUiThread { status.text = message } }
        server.start()
        registerDiscoveryService()
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.BLACK) }
        renderer = SurfaceViewRenderer(this)
        status = TextView(this).apply {
            text = "SCREENFLOW TV\nAguardando conexão do celular…"
            textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(28, 20, 28, 20)
            setBackgroundColor(0x99000000.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(renderer, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        root.addView(status, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        setContentView(root)
    }

    private fun onClientConnected(socket: Socket) {
        runOnUiThread {
            receiver?.stop()
            receiver = WebRtcReceiver(this, egl, renderer, socket) { message -> runOnUiThread { status.text = message } }
        }
    }

    private fun registerDiscoveryService() {
        val info = NsdServiceInfo().apply {
            serviceName = "ScreenFlow TV"
            serviceType = "_screenflow._tcp."
            port = PORT
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {
                runOnUiThread { status.text = "ScreenFlow TV pronto. Abra o ScreenFlow no celular." }
            }
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                runOnUiThread { status.text = "Falha ao anunciar a TV (código $errorCode)." }
            }
            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {}
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
        }
        registrationListener = listener
        nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    override fun onDestroy() {
        receiver?.stop()
        server.stop()
        registrationListener?.let { runCatching { nsd.unregisterService(it) } }
        renderer.release()
        egl.release()
        super.onDestroy()
    }

    companion object { private const val PORT = 8765 }
}
