package com.screenflow.tv

import android.content.Context
import android.util.Log
import org.json.JSONObject
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import java.net.Socket

internal class WebRtcReceiver(
    context: Context,
    private val egl: EglBase,
    private val renderer: SurfaceViewRenderer,
    socket: Socket,
    private val onStatus: (String) -> Unit
) {
    private val signal = SignalChannel(socket)
    private var factory: PeerConnectionFactory? = null
    private var peer: PeerConnection? = null
    @Volatile private var remoteDescriptionSet = false
    private val pendingCandidates = mutableListOf<IceCandidate>()

    init {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions()
        )
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()

        val config = PeerConnection.RTCConfiguration(emptyList())
        config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        peer = factory?.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                onStatus("Estado do vídeo: ${state?.name ?: "desconhecido"}")
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate ?: return
                sendCandidate(candidate)
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: org.webrtc.MediaStream?) {
                stream?.videoTracks?.firstOrNull()?.let(::attachTrack)
            }
            override fun onRemoveStream(stream: org.webrtc.MediaStream?) {}
            override fun onDataChannel(dataChannel: org.webrtc.DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: org.webrtc.RtpReceiver?, mediaStreams: Array<out org.webrtc.MediaStream>?) {
                (receiver?.track() as? VideoTrack)?.let(::attachTrack)
            }
            override fun onTrack(transceiver: org.webrtc.RtpTransceiver?) {
                (transceiver?.receiver?.track() as? VideoTrack)?.let(::attachTrack)
            }
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {
                onStatus("Conexão: ${newState?.name ?: "desconhecida"}")
            }
        }) ?: error("Não foi possível criar o receptor WebRTC")

        Thread({ runCatching { signal.readLoop(::handleSignal) }.onFailure { Log.e(TAG, "Leitura de sinalização falhou", it) } }, "ScreenFlowTvSignal").start()
    }

    private fun attachTrack(track: VideoTrack) {
        track.setEnabled(true)
        track.addSink(renderer)
        onStatus("Vídeo recebido; exibindo na televisão.")
    }

    private fun handleSignal(message: JSONObject) {
        when (message.optString("type")) {
            "offer" -> {
                val description = SessionDescription(SessionDescription.Type.OFFER, message.optString("sdp"))
                peer?.setRemoteDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        synchronized(pendingCandidates) {
                            pendingCandidates.forEach { peer?.addIceCandidate(it) }
                            pendingCandidates.clear()
                        }
                        createAnswer()
                    }
                    override fun onSetFailure(error: String?) {
                        sendError("Não foi possível abrir a oferta: $error")
                    }
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onCreateFailure(p0: String?) {}
                }, description)
            }
            "candidate" -> {
                val candidate = IceCandidate(
                    message.optString("sdpMid"),
                    message.optInt("sdpMLineIndex"),
                    message.optString("candidate")
                )
                if (remoteDescriptionSet) peer?.addIceCandidate(candidate)
                else synchronized(pendingCandidates) { pendingCandidates.add(candidate) }
            }
        }
    }

    private fun createAnswer() {
        peer?.createAnswer(object : SdpObserver {
            override fun onCreateSuccess(description: SessionDescription?) {
                description ?: return
                peer?.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        signal.send(JSONObject().put("type", "answer").put("sdp", description.description))
                        onStatus("Resposta enviada; estabelecendo conexão…")
                    }
                    override fun onSetFailure(error: String?) { sendError("Falha ao preparar resposta: $error") }
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onCreateFailure(p0: String?) {}
                }, description)
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(error: String?) { sendError("Falha ao criar resposta: $error") }
            override fun onSetFailure(error: String?) {}
        }, org.webrtc.MediaConstraints())
    }

    private fun sendCandidate(candidate: IceCandidate) {
        runCatching {
            signal.send(JSONObject()
                .put("type", "candidate")
                .put("sdpMid", candidate.sdpMid)
                .put("sdpMLineIndex", candidate.sdpMLineIndex)
                .put("candidate", candidate.sdp))
        }.onFailure { Log.w(TAG, "Falha ao enviar ICE", it) }
    }

    private fun sendError(message: String) {
        onStatus(message)
        runCatching { signal.send(JSONObject().put("type", "error").put("message", message)) }
    }

    fun stop() {
        signal.close()
        peer?.close(); peer?.dispose(); peer = null
        factory?.dispose(); factory = null
    }

    companion object { private const val TAG = "ScreenFlowWebRTC-TV" }
}
